package com.example.semesterexam.weapon;

public interface Archery {
    void addActionAttackArchery();
    void addBow();
    void addAttackBow();
    void addActionMoveBow();
    void addActionDieBow();

}
