package com.example.semesterexam.weapon;

public interface Lighting {

    void addActionAttackLighting();

    void addMagicWand();

    void addAttackMagicWand();

    void addActionMoveMagicWand();

    void addActionDieMagicWand();

}
