package com.example.semesterexam.weapon;

public interface BlueSlash {
    void addActionAttackBlueSlash();

    void addBlueSword();

    void addAttackBlueSword();

    void addActionMoveBlueSword();

    void addActionDieBlueSword();
}
