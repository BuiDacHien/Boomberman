package com.example.semesterexam.weapon;

public interface RedSlash {
    void addActionAttackRedSlash();

    void addRedSword();

    void addAttackRedSword();

    void addActionMoveRedSword();

    void addActionDieRedSword();
}
