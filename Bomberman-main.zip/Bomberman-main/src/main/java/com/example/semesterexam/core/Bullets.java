package com.example.semesterexam.core;

public enum Bullets {
    Arrow, IceBullet, FireBullet, SimpleFireGoal
}
