package com.example.semesterexam.exception;

public class AttackNameNotFound extends Exception {
    public AttackNameNotFound(String err) {
        super(err);
    }
}
