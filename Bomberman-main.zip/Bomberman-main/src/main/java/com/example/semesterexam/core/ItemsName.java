package com.example.semesterexam.core;

public enum ItemsName {
    SpeedUp, BalloonArrow, Immortal, FasterPutBoom, PlusHP, StopTime, IncreaseDamage, PlusBullet
}
