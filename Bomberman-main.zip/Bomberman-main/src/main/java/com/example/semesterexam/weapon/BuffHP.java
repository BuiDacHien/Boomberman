package com.example.semesterexam.weapon;

public interface BuffHP {
    void addActionAttackBuffHP();

    void addMagicWand();

    void addAttackMagicWand();

    void addActionMoveMagicWand();

    void addActionDieMagicWand();
}
