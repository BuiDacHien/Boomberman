package com.example.semesterexam.core;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
